package main;

public interface IOperateursControles {

	public void sequence();
	public void alternative();
	public void boucle();
	
}
