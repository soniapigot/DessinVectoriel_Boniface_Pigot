package figure;

//TODO
public class Bezier extends Chemin{

}
