package main;



import java.util.HashMap;

import figure.IChemin;
import outils.Crayon;
import outils.Position;

public class DessinComposite implements IDessin{

	private HashMap<String, IDessin> listeDessin;
	private HashMap<String, IChemin> listeChemin;
	
	public DessinComposite() {
		super();
	}
	

	public DessinComposite(HashMap<String, IDessin> listeDessin, HashMap<String, IChemin> listeChemin) {
		super();
		this.listeDessin = listeDessin;
		this.listeChemin = listeChemin;
	}

	public HashMap<String, IDessin> getListeDessin() {
		return listeDessin;
	}



	public void setListeDessin(HashMap<String, IDessin> listeDessin) {
		this.listeDessin = listeDessin;
	}



	public HashMap<String, IChemin> getListeChemin() {
		return listeChemin;
	}

	public void setListeChemin(HashMap<String, IChemin> listeChemin) {
		this.listeChemin = listeChemin;
	}

	public void sequence(){
	// TODO	
	}

	public void alternative(){
	//TODO
	}
	
	public void boucle(){
	//TODO
	}

	@Override
	public void dessiner(IChemin chemin, Crayon crayon) {
		chemin.dessiner(crayon);	
	}

	@Override
	public void remplir(IChemin chemin, Crayon crayon) {
		chemin.remplir(crayon);
		
	}

	@Override
	public void inserer(IDessin d1, IDessin d2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void etiqueter(IDessin d, Position p, String s) {
		// TODO Auto-generated method stub
		
	}
}
