package main;

import java.util.ArrayList;

import figure.IChemin;
import figure.Position;

public class CompositeDessin implements IDessin{

	private ArrayList<IDessin> dessins = new ArrayList<IDessin>();
	
	public CompositeDessin() {
		super();
	}
	
	public CompositeDessin(ArrayList<IDessin> dessins) {
		super();
		this.dessins = dessins;
	}
	
	public ArrayList<IDessin> getDessins() {
		return dessins;
	}

	public void setDessins(ArrayList<IDessin> dessins) {
		this.dessins = dessins;
	}

	@Override
	public void dessiner(IDessin d, IChemin chemin, Crayon crayon) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remplir(IDessin d, IChemin chemin, Crayon crayon) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void inserer(IDessin d1, IDessin d2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void etiqueter(IDessin d, Position p, String s) {
		// TODO Auto-generated method stub
		
	}
	
	public void sequence(){
	// TODO	
	}

	public void alternative(){
	//TODO
	}
	
	public void boucle(){
	//TODO
	}
}
