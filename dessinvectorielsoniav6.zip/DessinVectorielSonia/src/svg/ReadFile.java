package svg;

import java.io.*;
import java.util.HashMap;

import figure.Carre;
import figure.Cercle;
import figure.Point;
import figure.Rectangle;
import figure.Segment;
import figure.Triangle;
import main.DessinComposite;
import main.Forme;
import main.IDessin;
import outils.Couleurs;
import outils.Crayon;

public class ReadFile {
	
	public static boolean copyFile(File source, File dest){
		try{
			// Declaration et ouverture des flux
			java.io.FileInputStream sourceFile = new java.io.FileInputStream(source);
	 
			try{
				java.io.FileOutputStream destinationFile = null;
	 
				try{
					destinationFile = new FileOutputStream(dest);
	 
					// Lecture par segment de 0.5Mo 
					byte buffer[] = new byte[512 * 1024];
					int nbLecture;
	 
					while ((nbLecture = sourceFile.read(buffer)) != -1){
						destinationFile.write(buffer, 0, nbLecture);
					}
				} finally {
					destinationFile.close();
				}
			} finally {
				sourceFile.close();
			}
		} catch (IOException e){
			e.printStackTrace();
			return false; // Erreur
		}
	 
		return true; // R�sultat OK  
	}
	
	public void interpret(HashMap<String, DessinComposite> dessinsUtiles) throws IOException {

		
		
		File finit = new File("fichierSVG/dessinVide.svg");
		//On parcourt sur tous les dessins composites cr�� par l'utilisateur (il n'y a pas les dessins ins�r�s)
		for (HashMap.Entry<String, DessinComposite> entry: dessinsUtiles.entrySet()) {
			copyFile(finit,new File("C:/Users/Admin/Desktop/" + entry.getKey() + ".svg"));
			FileWriter writer = null;
			String texte = "";
			try{
			     writer = new FileWriter("C:/Users/Admin/Desktop/" + entry.getKey() + ".svg", true);
			     HashMap<String, Forme> listeForme = entry.getValue().getListeForme();
			     //On parcourt toutes les formes du dessin
			     for(HashMap.Entry<String, Forme> entryForme: listeForme.entrySet()) {
			    	 if (entryForme.getValue().getChemin() instanceof Cercle) {
			    		 Cercle c = (Cercle) entryForme.getValue().getChemin();
			    		 texte = "\r\n <circle cx=\"" + c.getCentre().getAbscisse() + "\" cy=\"" + c.getCentre().getOrdonnee() + "\" r=\"" + c.getDiametre() + "\" stroke=\"" + entryForme.getValue().getCrayonContour().getCouleur() + "\" stroke-width=\"" + entryForme.getValue().getCrayonContour().getEpaisseurTrait() + "\" fill=\"" + entryForme.getValue().getCrayonRemplir().getCouleur() + "\" />";
			    		 writer.write(texte,0,texte.length());
			    	 } 
			    	 else {
			    		 if (entryForme.getValue().getChemin() instanceof Segment) {
			    			 Segment s = (Segment) entryForme.getValue().getChemin();
			    			 texte = "\r\n <line x1=\"" + s.getPoint1().getAbscisse() + "\" x2=\"" + s.getPoint2().getAbscisse() + "\" y1=\"" + s.getPoint1().getOrdonnee() + "\" y2=\"" + s.getPoint2().getOrdonnee() + "\" stroke=\"" + entryForme.getValue().getCrayonContour().getCouleur() + "\" fill=\"" + entryForme.getValue().getCrayonRemplir().getCouleur() + "\" stroke-width=\"" + entryForme.getValue().getCrayonContour().getEpaisseurTrait() + "\"/>";
				    		 writer.write(texte,0,texte.length());
			    		 }
				    	 else {
				    		 if (entryForme.getValue().getChemin() instanceof Triangle) {
				    			 Triangle t = (Triangle) entryForme.getValue().getChemin();
				    			 texte = "\r\n <polygon points=\"" + t.getP1().getAbscisse() + "," + t.getP1().getOrdonnee() + " " + t.getP2().getAbscisse() + "," + t.getP2().getOrdonnee() + " " + t.getP3().getAbscisse() + "," + t.getP3().getOrdonnee() + "\" stroke=\"" + entryForme.getValue().getCrayonContour().getCouleur() + "\" fill=\"" + entryForme.getValue().getCrayonRemplir().getCouleur() + "\" stroke-width=\"" + entryForme.getValue().getCrayonContour().getEpaisseurTrait() + "\"/>";
					    		 writer.write(texte,0,texte.length());
				    		 }
					    	 else {
					    		 if (entryForme.getValue().getChemin() instanceof Carre) {
					    			 Carre car = (Carre) entryForme.getValue().getChemin();
					    			 texte = "\r\n <rect x=\"" + car.getP().getAbscisse() + "\" y=\"" + car.getP().getOrdonnee() + "\" width =\"" + car.getCote() + "\" height =\"" + car.getCote() + "\" stroke=\"" + entryForme.getValue().getCrayonContour().getCouleur() + "\" fill=\"" + entryForme.getValue().getCrayonRemplir().getCouleur() + "\" stroke-width=\"" + entryForme.getValue().getCrayonContour().getEpaisseurTrait() + "\"/>";
						    		 writer.write(texte,0,texte.length());
					    		 }
						    	 else {
						    		 if (entryForme.getValue().getChemin() instanceof Rectangle) {
						    			 Rectangle rec = (Rectangle) entryForme.getValue().getChemin();
						    			 texte = "\r\n <rect x=\"" + rec.getP().getAbscisse() + "\" y=\"" + rec.getP().getOrdonnee() + "\" width =\"" + rec.getLongueur() + "\" height =\"" + rec.getHauteur() + "\" stroke=\"" + entryForme.getValue().getCrayonContour().getCouleur() + "\" fill=\"" + entryForme.getValue().getCrayonRemplir().getCouleur() + "\" stroke-width=\"" + entryForme.getValue().getCrayonContour().getEpaisseurTrait() + "\"/>";
							    		 writer.write(texte,0,texte.length());
						    		 }
						    	 }
					    	 }
				    	 }
			    	 }
			     }
			     
			     String texteSVG = "\r\n </svg>";
			     writer.write(texteSVG,0,texteSVG.length());
			     
			}catch(IOException ex){
			    ex.printStackTrace();
			}finally{
			  if(writer != null){
			     writer.close();
			  }
			}
			Runtime rt = null;
			rt = Runtime.getRuntime();
			rt.exec("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe " + "file:///C:/Users/Admin/Desktop/" + entry.getKey() + ".svg");
		}
	}
	
}