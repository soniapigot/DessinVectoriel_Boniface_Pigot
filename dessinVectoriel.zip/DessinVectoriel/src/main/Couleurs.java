package main;

public enum Couleurs {
	
	rouge, jaune, bleu, vert, rose, violet, orange, blanc, noir, marron, gris; 

}
