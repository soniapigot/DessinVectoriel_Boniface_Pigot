package Figure;

//TODO
public class Bezier {

}
