package Figure;

public interface IChemin {

}
