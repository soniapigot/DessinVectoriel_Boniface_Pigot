package soniamodif;

import figure.IChemin;
import figure.Point;
import outils.Crayon;

public class Carre implements IChemin{
	
	private Point p;
	private int cote;
	public Carre(Point p, int cote) {
		super();
		this.p = p;
		this.cote = cote;
	}
	public Point getP() {
		return p;
	}
	public void setP(Point p) {
		this.p = p;
	}
	public int getCote() {
		return cote;
	}
	public void setCote(int cote) {
		this.cote = cote;
	}
	@Override
	public void dessiner(Crayon crayon) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void remplir(Crayon crayon) {
		// TODO Auto-generated method stub
		
	}
	
	

}
