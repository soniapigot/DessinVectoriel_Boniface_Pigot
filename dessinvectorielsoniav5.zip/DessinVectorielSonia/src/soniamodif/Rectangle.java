package soniamodif;

import figure.IChemin;
import figure.Point;
import outils.Crayon;

public class Rectangle implements IChemin{
	
	private Point p;
	private int longueur;
	private int hauteur;
	public Rectangle(Point p, int longueur, int hauteur) {
		super();
		this.p = p;
		this.longueur = longueur;
		this.hauteur = hauteur;
	}
	public Point getP() {
		return p;
	}
	public void setP(Point p) {
		this.p = p;
	}
	public int getLongueur() {
		return longueur;
	}
	public void setLongueur(int longueur) {
		this.longueur = longueur;
	}
	public int getHauteur() {
		return hauteur;
	}
	public void setHauteur(int hauteur) {
		this.hauteur = hauteur;
	}
	@Override
	public void dessiner(Crayon crayon) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void remplir(Crayon crayon) {
		// TODO Auto-generated method stub
		
	}

}
