package Figure;

public interface IFigure {

}
