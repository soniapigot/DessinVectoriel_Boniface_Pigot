package Figure;

// a supprimer (je pense)
public interface IFigure {

}
