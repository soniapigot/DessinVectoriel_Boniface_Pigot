package outils;

public enum Couleurs {
	
	red, yellow, blue, green, pink, purple, orange, white, black, grey, none; 

}
