package Figure;

import main.ICommandesFondamentales;

public class Chemin implements ICommandesFondamentales{

	@Override
	public void dessiner() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remplir() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void inserer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void etiqueter() {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
