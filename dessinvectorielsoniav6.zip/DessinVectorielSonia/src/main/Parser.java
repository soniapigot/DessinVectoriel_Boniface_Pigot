package main;

import java.io.IOException;
import java.util.HashMap;

import figure.Carre;
import figure.Cercle;
import figure.Point;
import outils.Couleurs;
import outils.Crayon;
import svg.ReadFile;

public class Parser {
	
	private HashMap<String, DessinComposite> dessins = new HashMap<String, DessinComposite>();
	
	public Parser() {
		//Construire la variable d'instance dessins
		HashMap<String, Forme> chemin = new HashMap<String, Forme>();
		DessinComposite dessin = new DessinComposite(new HashMap<String, IDessin>(), chemin);
		Cercle cercle = new Cercle(new Point(40,50), 10);
		Forme forme = new Forme(cercle, new Crayon(2, Couleurs.orange), new Crayon(2, Couleurs.transparent));
		dessin.getListeForme().put("cercle1", forme);		
		Carre carre = new Carre(new Point(10,60), 10);
		Forme formeCarre = new Forme(carre, new Crayon(1, Couleurs.red), new Crayon(2, Couleurs.transparent));
		dessin.getListeForme().put("carre1", formeCarre);
		dessins.put("dessinSoso", dessin);
	}
	
	public void evaluate(String formatAffichage) throws IOException {
		if (formatAffichage.equals("svg")) {
			ReadFile r = new ReadFile();
			r.interpret(dessins);
		}
		else {
			
		}
		
	}

}
