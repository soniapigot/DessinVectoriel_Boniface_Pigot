package figure;

import outils.Crayon;

//TODO
public class Bezier implements IChemin{

	@Override
	public void dessiner(Crayon crayon) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remplir(Crayon crayon) {
		// TODO Auto-generated method stub
		
	}

}
