package main;

import java.io.IOException;
import java.util.HashMap;

import graphics2DInterpretation.JAVA;
import patronBuilder.*;
import patronComposite.DessinComposite;
import operateursDeControle.Alternative;
import operateursDeControle.Boucle;
import outils.*;
import svgInterpretation.SVG;

// Cette classe permet � l'utilisateur de composer un ou plusieurs dessins.
// Elle renvoit une instance de Builder, dont l'attribut est une HashMap 
// r�pertoriant chaque dessin que l'utilisateur souhaite afficher � l'�cran
// associ� � un nom 
public class Builder {

	private HashMap<String, DessinComposite> dessins;

	// Ce constructeur sert � instancier dessins
	// C'est ici que l'utilisateur peut �crire son script de dessins en utilisant
	// des instances des builders pour les objets qu'ils veut cr�er.
	public Builder () {

		// initialisation de l'instance
		this.dessins = new HashMap<String, DessinComposite>();

		// creation 1er dessin
		DessinBuilder dessinBuilder1 = new DessinBuilder();

		FormeBuilder formeBuilder1 = new FormeBuilder();
		FormeBuilder formeBuilder2 = new FormeBuilder();

		CarreBuilder carreBuilder1 = new CarreBuilder();
		CercleBuilder cercleBuilder1 = new CercleBuilder();

		CrayonBuilder crayonBuilder1 = new CrayonBuilder();
		CrayonBuilder crayonBuilder2 = new CrayonBuilder();
		CrayonBuilder crayonBuilder3 = new CrayonBuilder();
		CrayonBuilder crayonBuilder4 = new CrayonBuilder();

		dessinBuilder1.ajouterForme(formeBuilder1
				.ajouterChemin(carreBuilder1.choisirPointOrigine(300, 300).choisirLongueurCote(10).creerCarre())
				.ajouterCrayonContour(crayonBuilder1.choisirEpaisseur(1).choisirCouleur(Couleurs.black).creerCrayon())
				.ajouterCrayonRemplir(crayonBuilder2.choisirEpaisseur(3).choisirCouleur(Couleurs.blue).creerCrayon())
				.creerForme());

		dessinBuilder1.ajouterForme(formeBuilder2
				.ajouterChemin(cercleBuilder1.choisirCentre(150,200).choisirDiametre(10).creerCercle())
				.ajouterCrayonRemplir(crayonBuilder3.choisirEpaisseur(1).choisirCouleur(Couleurs.black).creerCrayon())
				.ajouterCrayonRemplir(crayonBuilder4.choisirEpaisseur(3).choisirCouleur(Couleurs.blue).creerCrayon())
				.creerForme());


		// creation 2e dessin
		DessinBuilder dessinBuilder2 = new DessinBuilder();

		FormeBuilder formeBuilder3 = new FormeBuilder();

		SegmentBuilder segmentBuilder1 = new SegmentBuilder();

		EtiquetteBuilder etiquetteBuilder1 = new EtiquetteBuilder();

		CrayonBuilder crayonBuilder5 = new CrayonBuilder();
		CrayonBuilder crayonBuilder6 = new CrayonBuilder();

		

		dessinBuilder2.ajouterEtiquette(etiquetteBuilder1
				.choisirPoint(100, 450)
				.choisirTexte("etiquette")
				.choisirCrayon(3, Couleurs.purple)
				.creerEtiquette());

		// exemple d'utilisation de la classe Boucle
		Boucle b = new Boucle(3, new FormeBuilder());
		CrayonBuilder crayonBuilder7 = new CrayonBuilder();
		CrayonBuilder crayonBuilder8 = new CrayonBuilder();
		Crayon crayonContour = crayonBuilder7.choisirCouleur(Couleurs.blue).choisirEpaisseur(2).creerCrayon();
		Crayon crayonRemplir = crayonBuilder8.choisirCouleur(Couleurs.red).choisirEpaisseur(2).creerCrayon();
		dessinBuilder2 = b.creerCerclesConcentriques(200, 200, 100, 100, crayonContour, crayonRemplir, dessinBuilder2);

		dessinBuilder2.ajouterForme(formeBuilder3
				.ajouterChemin(segmentBuilder1.choisirPoint1(100,350).choisirPoint2(100,400).creerSegment())
				.ajouterCrayonRemplir(crayonBuilder5.choisirEpaisseur(1).choisirCouleur(Couleurs.black).creerCrayon())
				.ajouterCrayonRemplir(crayonBuilder6.choisirEpaisseur(3).choisirCouleur(Couleurs.blue).creerCrayon())
				.creerForme());
		
		DessinComposite d2 = dessinBuilder2.creerDessin();

		// rajoute d2 � la liste des dessins de d1
		dessinBuilder1.ajouterDessin(d2);

		// renvoit le dessinComposite 1
		DessinComposite d1 = dessinBuilder1.creerDessin();
		
		// Exemple d'utilisation de la classe Alternative
		Alternative a = new Alternative(d1);
		d1 = a.remplirFormeEnFonctionDeSonContour(0, Couleurs.blue, Couleurs.orange);

		// Ajouter les dessins cr��s dans la liste des dessins � afficher, en leur donnant un nom
		this.dessins.put("MonDessin1", d1);
		this.dessins.put("MonDessin2", d2);

	}
	// Interpr�te le script donn� par l'utilisateur en utilisant les objets java 
	// cr��s et stock�s dans la HashMap dessins
	public void evaluate(String formatAffichage) throws IOException {
		if (formatAffichage.equals("svg")) {
			SVG r = new SVG();
			r.interpret(dessins);
		}
		else {
			JAVA i = new JAVA();
			i.interpret(dessins);
		}


	}

}
