package figure;

// a supprimer (je pense)
public interface IFigure {

}
