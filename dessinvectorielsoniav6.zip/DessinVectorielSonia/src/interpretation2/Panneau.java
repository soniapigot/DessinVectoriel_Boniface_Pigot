package interpretation2;

import java.awt.Graphics;
import javax.swing.JPanel;

import figure.Carre;
import figure.Point;
 
public class Panneau extends JPanel { 
	
	
  public void paintComponent(Graphics g){
    //Vous verrez cette phrase chaque fois que la m�thode sera invoqu�e
    System.out.println("Je suis ex�cut�e !"); 
    Carre car = new Carre(new Point(10,60), 10);
    Bibliotheque.createCarre(g, car);
  }               
}
