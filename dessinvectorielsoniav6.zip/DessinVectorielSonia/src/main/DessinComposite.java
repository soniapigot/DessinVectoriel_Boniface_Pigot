package main;

import java.util.HashMap;

import figure.IChemin;
import outils.Crayon;
import outils.Position;

public class DessinComposite implements IDessin{

	private HashMap<String, IDessin> listeDessin;
	private HashMap<String, Forme> listeForme;
	
	public DessinComposite() {
		super();
	}
	

	public DessinComposite(HashMap<String, IDessin> listeDessin, HashMap<String, Forme> listeForme) {
		super();
		this.listeDessin = listeDessin;
		this.listeForme = listeForme;
	}

	public HashMap<String, IDessin> getListeDessin() {
		return listeDessin;
	}



	public void setListeDessin(HashMap<String, IDessin> listeDessin) {
		this.listeDessin = listeDessin;
	}



	public HashMap<String, Forme> getListeForme() {
		return listeForme;
	}

	public void setListeForme(HashMap<String, Forme> listeForme) {
		this.listeForme = listeForme;
	}

	public void sequence(){
	// TODO	
	}

	public void alternative(){
	//TODO
	}
	
	public void boucle(){
	//TODO
	}

	@Override
	public void dessiner(IChemin chemin, Crayon crayon) {
		chemin.dessiner(crayon);	
	}

	@Override
	public void remplir(IChemin chemin, Crayon crayon) {
		chemin.remplir(crayon);
		
	}

	@Override
	public void inserer(IDessin d1, IDessin d2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void etiqueter(IDessin d, Position p, String s) {
		// TODO Auto-generated method stub
		
	}
}
