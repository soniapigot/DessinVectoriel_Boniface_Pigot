package main;

public interface ICommandesFondamentales {
	
	public void dessiner();
	public void remplir();
	public void inserer();
	public void etiqueter();
	

}
