package main;

import java.io.IOException;

public class Main {
	
	public static void main(String[] args) throws IOException {
		Builder b = new Builder();
		
		b.evaluate("svg");
	}

}
