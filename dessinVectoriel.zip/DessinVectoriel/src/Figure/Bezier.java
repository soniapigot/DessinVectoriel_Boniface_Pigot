package Figure;

//TODO
public class Bezier implements IChemin{

}
