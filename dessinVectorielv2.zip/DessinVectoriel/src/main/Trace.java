package main;

import figure.Chemin;
import figure.IChemin;
import figure.Position;


//so: a supprimer je pense
public class Trace implements IDessin{

	private Chemin chemin;
	private Crayon crayon;
	
	@Override
	public void dessiner(IDessin d, IChemin chemin, Crayon crayon) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remplir(IDessin d, IChemin chemin, Crayon crayon) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void inserer(IDessin d1, IDessin d2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void etiqueter(IDessin d, Position p, String s) {
		// TODO Auto-generated method stub
		
	}

	
}
