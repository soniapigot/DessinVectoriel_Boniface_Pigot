package main;

import figure.IChemin;
import outils.Crayon;
import outils.Position;

public class DessinVide implements IDessin {

	@Override
	public void dessiner(IChemin chemin, Crayon crayon) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remplir(IChemin chemin, Crayon crayon) {
		// TODO Auto-generated method stub

	}

	@Override
	public void inserer(IDessin d1, IDessin d2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void etiqueter(IDessin d, Position p, String s) {
		// TODO Auto-generated method stub

	}

}
