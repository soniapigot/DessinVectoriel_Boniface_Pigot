package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import figure.Cercle;
import figure.IChemin;
import figure.Point;
import outils.Couleurs;
import outils.Crayon;


//REVOIR CHOIXFORME et CHOIXCOMMANDE
public class CreationObjetJava {

	public static void main(String[] args) {
		lancementApplication();
	}

	public static void lancementApplication(){

		System.out.println("Bienvenue dans l'application r�volutionnaire de Dessin Vectoriel de Sonia & M�lyna \n"
				+"Une nouvelle feuille de dessin a �t� ouverte. \n"
				+"Le mode par d�faut est SEQUENCE : vos instructions seront ex�cut�es les unes � la suite des autres. \n"
				+"Pour changer de mode, veuiller indiquez � tout moment BOUCLE ou ALTERNATIVE. \n"
				+"----------------------------------------------------------------------------------------------------");

		// creation stockage des feuilles de dessins
		HashMap<String, IDessin> dessinsUtiles = new HashMap<String, IDessin>();
		IDessin dessinInitial = new DessinComposite(null, null);
		dessinsUtiles.put("dessinInitial", dessinInitial);

		// proposition des commandes fondamentales � l'utilisateur
		while(true){
			nouvellesCommandes();
			String commande = Clavier.lireString();
			choixCommande(commande, dessinsUtiles);
		}






	}

	public static void nouvellesCommandes(){
		System.out.println("Que voulez-vous faire ? \n"
				+ "- Ouvrir une nouvelle feuille de dessin : tapez dessin \n"
				+ "- Dessiner : tapez dessiner \n"
				+ "- Remplir une forme : tapez remplir \n"
				+ "- Ins�rer un dessin dans un autre dessin : tapez inserer \n"
				+ "- Etiqueter un texte: tapez etiqueter \n");
	}

	public static void choixCommande(String commande, HashMap<String, IDessin> dessinsUtiles){
		switch(commande){
		case "dessin" : creationDessin(dessinsUtiles); break;
		case "dessiner" : creerForme(); choixCrayon(); break;
		case "inserer" : choixDessinAInserer(dessinsUtiles); choixDessinDansLequelInserer(dessinsUtiles); break;
		case "remplir" : choixCrayon(); break; //choixForme(); 
		case "etiqueter" : choixTexte(); break;

		}
	}

	public static void creationDessin(HashMap<String, IDessin> dessinsUtiles){
		String nomDessin = choixNom();
		IDessin dessin = new DessinComposite(null, null);
		dessinsUtiles.put(nomDessin, dessin);

		//test
		for (String key : dessinsUtiles.keySet()) {
			System.out.println(key);
		}


	}

	public static String choixNom(){
		System.out.println("Quel nom voulez-vous lui donner ?");
		String nom = Clavier.lireString();
		return nom;
	}

	public static void creerForme(){
		System.out.println("Quelle forme voulez-vous dessiner ? \n"
				+ "- carr� : tapez carre \n"
				+ "- cercle : tapez cercle ");
		String forme = Clavier.lireString();
		switch(forme){
		case "cercle" : creerCercle(); break;
		}
	}

	public static Crayon choixCrayon(){
		System.out.println("Quel crayon voulez-vous utiliser ?");
		System.out.println("Quelle �paisseur ? \n"
				+ "- 1 \n"
				+ "- 2 \n"
				+ "- 3 \n");
		int epaisseur = Clavier.lireInt();

		System.out.println("Quelle couleur ? \n"
				+ "- rouge \n"
				+ "- bleu \n"
				+ "- vert \n");

		Couleurs couleurCrayon = Couleurs.red;
		String couleur = Clavier.lireString();
		switch(couleur){
		case "rouge" : couleurCrayon = Couleurs.red; break;
		case "bleu" : couleurCrayon = Couleurs.blue; break;
		case "vert" : couleurCrayon = Couleurs.green; break;
		}

		Crayon crayon = new Crayon(epaisseur, couleurCrayon);
		return crayon;
	}

	public static Cercle creerCercle(){
		System.out.println("Abscisse du centre ?");
		int abscisse = Clavier.lireInt();
		System.out.println("Ordonn�e du centre ?");
		int ordonnee = Clavier.lireInt();
		System.out.println("Diam�tre ?");
		int diametre = Clavier.lireInt();

		Point centre = new Point(abscisse, ordonnee);
		Cercle cercle = new Cercle(centre, diametre);
		return cercle;

	}
	
	public static IDessin choixDessinAInserer(HashMap<String, IDessin> dessinsUtiles){
		String dessinsDisponibles = "Voici les dessins que vous avez � disposition : \n";
		for (String key : dessinsUtiles.keySet()) {
			dessinsDisponibles += "- " + key + "\n";
		}
		System.out.println("Quel dessin voulez-vous ins�rer ?");
		System.out.println(dessinsDisponibles);
		
		String nomDessin = Clavier.lireString();
		return dessinsUtiles.get(nomDessin);		
	}
	
	public static IDessin choixDessinDansLequelInserer(HashMap<String, IDessin> dessinsUtiles){
		String dessinsDisponibles = "Voici les dessins que vous avez � disposition : \n";
		for (String key : dessinsUtiles.keySet()) {
			dessinsDisponibles += "- " + key + "\n";
		}
		System.out.println("Dans quel dessin voulez-vous ins�rer le dessin choisi ?");
		System.out.println(dessinsDisponibles);
		
		String nomDessin = Clavier.lireString();
		return dessinsUtiles.get(nomDessin);		
	}
	
	public static IChemin choixForme(DessinComposite dessin){
		System.out.println("Quelle forme voulez-vous remplir ?");
		String formesDisponibles = "Voici les formes � dispositions dans ce dessin : \n";
//		ArrayList<IChemin> listeChemin = dessin.getListeChemin();
//		for(IChemin c: listeChemin){
//			formesDisponibles += "- c";
//		}

		return null;
	}
	public static void choixCouleur(){
		System.out.println("choix Couleur");
	}
	public static void choixTexte(){
		System.out.println("choix Texte");
	}






}
