package interpretation2;



public class Int2{

	public static void main(String[] args) {

		
		Fenetre fen = new Fenetre();
		
		
	}

}
