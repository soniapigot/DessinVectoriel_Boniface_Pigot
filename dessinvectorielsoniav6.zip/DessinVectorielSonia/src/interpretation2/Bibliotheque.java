package interpretation2;

import java.awt.Graphics;

import figure.Carre;

public class Bibliotheque {
	
	public static void createCarre(Graphics g, Carre car) {
		g.drawRect(car.getP().getAbscisse(), car.getP().getOrdonnee(), car.getCote(), car.getCote());
	}

}
