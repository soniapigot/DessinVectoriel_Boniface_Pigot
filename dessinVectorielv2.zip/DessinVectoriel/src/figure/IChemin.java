package figure;

//so: a suuprimer je pense
public interface IChemin {

}
